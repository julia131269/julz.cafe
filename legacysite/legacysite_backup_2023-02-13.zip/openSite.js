
window.open("https://www.julz.cafe","_self");
function execute(){
  window.open("https://www.julz.cafe","_self");
}